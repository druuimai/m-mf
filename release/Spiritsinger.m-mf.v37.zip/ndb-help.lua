{
  {
    term = "mmconfig politics",
    definition = {
      "Gives you a menu where you can adjust org relationship stances, and setup highlights."
    }
  },
  {
    term = "mmconfig autohonors yep/nope",
    definition = {
      "Sets whenever NameDB should automatically honors new people it comes across to gather information about them or not."
    }
  },
  {
    term = "ndb",
    definition = {
      "NameDB alias cheetsheet - shows the same information as this aliases list. Hover your mouse or click on an alias to see the description."
    }
  },
  {
    term = "ndb long",
    definition = {
      "NameDB alias cheetsheet, with the descriptions expanded."
    }
  },
  {
    term = "qw",
    definition = {
      "Checks the QW list, from which ndb will be able to pick up new names from."
    }
  },
  {
    term = "qw update",
    definition = {
      "Re-checks all names on the QW list, even if they're already and currently known."
    }
  },
  {
    term = "qwc",
    definition = {
      "Checks the QW list, from which ndb will be able to pick up new names from. It'll also display you a menu of players present by their organization affiliation, sorted:"
    }
  },
  {
    term = "ppof <org>",
    definition = {
      "Reports the members of an org to an m&mf cc channel. You can shorten the name of an org, ie *ppof glom* will work."
    }
  },
  {
    term = "guild/order/city/commune enemies",
    definition = {
      "Sets the enemy status of the people that NameDB knows of from those lists. This won't auto-add names it doesn't know for checking (so your db doesn't get filled up with dormant people and they'll be getting highlighted for no reason)."
    }
  },
  {
    term = "guild/order/city/commune enemies add",
    definition = {
      "Sets the enemy status of the people from those lists, and auto-adds names it doesn't know for checking."
    }
  },
  {
    term = "cwho",
    definition = {
      "Adds the persons class information into cwho list. An (h) will be visible if the person is a Demigod or an Ascendant - H stands for them being able to access Havens. The cwho list looks best with ``CONFIG PREFERREDWIDTH 100`` in order to have the class name fit in."
    }
  },
  {
    term = "ndb honorsnew",
    definition = {
      "If mmconfig autohonors is off, ndb honorsnew will allow NameDB to honors the new people it knows of."
    }
  },
  {
    term = "ndb cancel",
    definition = {
      "Stops honors'ing the list of people that need to be checked."
    }
  },
  {
    term = "npp",
    definition = {
      "Stops/resumes name highlighting. You might want to turn highlighting off for wargames, for example, where the game-provided colors are more important."
    }
  },
  {
    term = "npp on/off",
    definition = {
      "Stops/resumes name highlighting explicitly."
    }
  },
  {
    term = "mmconfig highlightignore <person>",
    definition = {
      "Adds/removes a name on the list that keeps track of who should not be highlighted."
    }
  },
  {
    term = "mmshow highlightignore",
    definition = {
      "Shows the list of persons who shouldn't be highlighted."
    }
  },
  {
    term = "iff <person> ally/enemy/auto",
    definition = {
      "Explicitly sets a persons status to you, overriding the auto-determination of enemy vs non-enemy by NameDB.",
      "",
      "Making them an ally will make NameDB disregard their citizenship and political stances and whenever they're a guild/order/city/commune enemy - thus never considering them an enemy.",
      "",
      "Making them an enemy will always consider them an enemy, disregarding anything else.",
      "",
      "Setting it to auto will have NameDB compute their status to you depending on a number of things - if they're in a org that is considered an enemy to you, or if they're a guild/org/order enemy, they'll be considered an enemy. Otherwise, they won't be an enemy. Note that if someone is in an org that is allied with yours and they are an enemy of your org, they will not be considered an enemy."
    }
  },
  {
    term = "ndb set <person> notes <notes>",
    definition = {
      "Adjusts the notes you have on the person to the new ones. If you do *whois person* and click on *'edit'*, you an edit current notes you have on them. You can use the same color formatting from a cecho to color your notes (ie *<red> text*), and insert \\n's in the same manner to get a linebreak."
    }
  },
  {
    term = "ndb export",
    definition = {
      "Opens up a menu where you can export your data. It allows you to selectively export fields (so you don't have to share everything, for example, not your notes), and which people to export (atm, it's everybody)."
    }
  },
  {
    term = "ndb import",
    definition = {
      "Opens up a menu where you can import exported NameDB data. You can selectively choose which fields about a person should be imported - they will overwrite what you've had. This will not clear your names in NameDB that you've got already - if you'd like to start clean, use 'ndb delete all'."
    }
  },
  {
    term = "ndb delete <person>",
    definition = {
      "Wipes an individual entry from NameDB."
    }
  },
  {
    term = "ndb delete all",
    definition = {
      "Wipes all data from the database, essentially making you start over clean. You have to use this alias twice for it to go off. If you have a lot of names (10k+), expect to wait a few seconds for it to finish."
    }
  },
  {
    term = "ndb update all",
    definition = {
      "Re-checks every person in the database. This can't be undone, only paused (with *ndb cancel*) - NameDB will re-check everybody as you've asked it to, so don't do it on a whim!"
    }
  },
  {
    term = "ndb set <person> class <class>",
    definition = {
      "Manually sets/adjusts the persons class. It's always stored in lowercase by NameDB. NameDB automatically picks up the class from cwho and gwho lists, but this isn't possible for everyone."
    }
  },
  {
    term = "ndb set <person> city/commune/org <city/commune>",
    definition = {
      "Manually changes the persons city/commune. It's always stored in proper case (first letters capitalized) by NameDB. NameDB automatically picks it up from honors for you already."
    }
  },
  {
    term = "ndb set <person> title <title>",
    definition = {
      "Adjusts the persons title as NameDB knows it. It's not really useful for much, as titles change all the time, but the option to set/retrieve them is there for you."
    }
  },
  {
    term = "ndb set <person> org_rank <rank>",
    definition = {
      "Manually adjusts the persons org rank. 0 is known, 1 is cr1 and 6 is cr6. NameDB automatically picks up the org rank from honors for you when it is shown."
    }
  },
  {
    term = "ndb set <person> guild <guild>",
    definition = {
      "Manually adjusts the persons guild affiliation. NameDB can only capture this from gwho or guild members, so you'd want to use this for setting others' guilds if that's something you want to track."
    }
  },
  {
    term = "ndb set <person> order <order>",
    definition = {
      "Manually adjusts the persons Order affiliation. NameDB stores it with proper titlecase, and it'll pull information from ORDER MEMBERS for you. You will need to manually input the members of other Orders though."
    }
  },
  {
    term = "ndb set <person> might <might>",
    definition = {
      "Adjusts the persons might (lessons invested vs you) relative to you - 0 is 0% of your might, 100 is equal to you. *-1* is unknown, and will cause NameDB to re-honors the person. NameDB automatically captures this from honors."
    }
  },
  {
    term = "ndb set <person> importance <number>",
    definition = {
      "Manually sets a persons \"importance\". This isn't used by NameDB, but it's a way for you to explicitly prioritize people without relying on heuristics such as org rank and might."
    }
  },
  {
    term = "ndb set <person> xp_rank <number>",
    definition = {
      "Manually sets the persons rank in experience in the game. *-2* is unranked, *-1* is unknown - this'll cause NameDB to auto-honors the person. Any other number is their actual rank. NameDB automatically captures this from honors."
    }
  },
  {
    term = "ndb set <person> immortal <yep/nope>",
    definition = {
      "Manually adjusts whenever somebody is an Immortal or not. This means Gods, Ephemereals and admins. NameDB automatically captures this from honors."
    }
  },
  {
    term = "ndb set <person> orgenemy/guildenemy/orderenemy <yep/nope>",
    definition = {
      "Manually sets whenever the person is your orgs, guilds or orders enemy.  NameDB automatically captures this from the enemy lists, but you can adjust it manually as well."
    }
  },
  {
    term = "ndb stats",
    definition = {
      "A little stats alias showing the number of people known and city populations."
    }
  },
  {
    term = "mmconfig watchfor <name>",
    definition = {
      "Adds or removes a person on the watchfor list - used in as a custom highlighting category in NameDB. You can script this as well - put the name down as a key in the ``mm.me.watchfor`` table. To remove a name, set it to nil (not false)."
    }
  }
}